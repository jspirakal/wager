<template>
     <header>
           <header>
             <router-link to="/">
              <img src="img/logo.png" alt="LOGO">
                        <P class="logo_text">“The gamer’s professional career begins here”</P>
               
             </router-link>
            </header>
      </header>
</template>
<script>
export default {
  name: 'MainHeader'
}
</script>