<template>
    <div class="container-fluid social-info mt-5">
        <ul>
                <li>
                        <p class="icon">
                                <i class="fa fa-twitter"></i>
                        </p>
                        <p class="icon-content">
                                 Twitter Followers <br>
                                <span>7, 34 , 345 , 1</span>
                        </p>
                </li>
                <li>
                        <p class="icon">
                                        <i class="fa fa-facebook"></i>
                        </p>
                        <p class="icon-content">
                                       
                                        Facebook  Likes <br>
                                        <span>78 ,2345</span>
                        </p>
                        
                </li>
                <li>
                        <p class="icon"><i class="fa fa-user"></i></p>
                       <p class="icon-content">
                                
                        Fans <br>
                        <span>12345 , 567 , 67</span>
                       </p>
                </li>
        </ul>
    </div>
</template>

<script>
export default {
    name: 'FooterSocial'
}
</script>
