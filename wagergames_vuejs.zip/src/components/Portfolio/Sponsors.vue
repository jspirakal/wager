<template>
      <div class="row">
            <div class="col-md-12 pl-0 pr-0">
                    <h5 class="heading">Sponsors</h5>
                    <div class="sponsors">
                            <div>
                                    <img src="img/sponsor_nike.png" alt="">
                            </div>
                            <div>
                                    <img src="img/sponsor_red_bull.png" alt="">
                            </div>
                            <div>
                                    <img src="img/sponsor_pepsi.png" alt="">
                            </div>
                            <div>
                                    <img src="img/sponsor_ray_ban.png" alt="">
                            </div>
                            <div>
                                    <img src="img/sponsor_james.png" alt="">
                            </div>

                            <div>
                                    <img src="img/sponsor_nike.png" alt="">
                            </div>
                            <div>
                                    <img src="img/sponsor_red_bull.png" alt="">
                            </div>
                            <div>
                                    <img src="img/sponsor_pepsi.png" alt="">
                            </div>
                            <div>
                                    <img src="img/sponsor_ray_ban.png" alt="">
                            </div>
                            <div>
                                    <img src="img/sponsor_james.png" alt="">
                            </div>
                    </div>
            </div>
    </div>
</template>

<script>
export default {
    name: 'Sponsors'
}
</script>

<style>

</style>
