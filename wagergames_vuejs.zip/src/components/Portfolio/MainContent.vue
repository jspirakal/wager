<template>
     <div class="col-md-8 main-content">
        <div class="row">
                <div class="col-md-6">
                        <h5 class="heading">Current Teams</h5>
                        <div class="current-team">
                            <div>
                                    <img src="img/current_team1.png" alt="Team 1">
                                    <h5>Team Name</h5>
                            </div>
                            <div>
                                    <img src="img/current_team2.png" alt="Team 2">
                                    <h5>Team Name</h5>
                            </div>
                            <div>
                                    <img src="img/current_team1.png" alt="Team 1">
                                    <h5>Team Name</h5>
                            </div>
                            <div>
                                    <img src="img/current_team2.png" alt="Team 2">
                                    <h5>Team Name</h5>
                            </div>
                            
                            </div>
                </div>
                <div class="col-md-6">
                        <h5 class="heading">Past Teams</h5>
                        <div class="current-team">
                            <div>
                                    <img src="img/past_team1.png" alt="Team 1">
                                    <h5>Team Name</h5>
                            </div>
                            <div>
                                    <img src="img/past_team2.png" alt="Team 2">
                                    <h5>Team Name</h5>
                            </div>
                            <div>
                                    <img src="img/past_team1.png" alt="Team 1">
                                    <h5>Team Name</h5>
                            </div>
                            <div>
                                    <img src="img/past_team2.png" alt="Team 2">
                                    <h5>Team Name</h5>
                            </div>
                            
                            </div>
                </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                    <h5 class="heading">Badges</h5> 
                    <div class="badges">
                            <div>
                                    <img src="img/badges1.png" alt="">
                            </div>
                            <div>
                                    <img src="img/badges2.png" alt="">
                            </div>
                            <div>
                                    <img src="img/badges3.png" alt="">
                            </div>
                            <div>
                                    <img src="img/badges4.png" alt="">
                            </div>
                            <div>
                                    <img src="img/badges1.png" alt="">
                            </div>
                            <div>
                                    <img src="img/badges2.png" alt="">
                            </div>
                            <div>
                                    <img src="img/badges3.png" alt="">
                            </div>
                            <div>
                                    <img src="img/badges4.png" alt="">
                            </div>
                    </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                    <h5 class="heading">Achivements</h5> 
                    <div class="achivements">
                            <div>
                                    <img src="img/achivement1.png" alt="">
                                    <h5 class="rank">1st</h5>
                                    <h5>April 2018</h5>
                                    <h5>Stadium 2018</h5>
                            </div>
                            <div>
                                    <img src="img/achivement2.png" alt="">
                                    <h5 class="rank">1st</h5>
                                    <h5>MPL GG</h5>
                                    <h5>Stadium 2018</h5>
                            </div>
                            <div>
                                    <img src="img/achivement3.png" alt="">
                                    <h5 class="rank">1st</h5>
                                    <h5>Louvae Assembly</h5>
                                    <h5>Stadium 2018</h5>
                            </div>
                            <div>
                                    <img src="img/achivement1.png" alt="">
                                    <h5 class="rank">1st</h5>
                                    <h5>April 2018</h5>
                                    <h5>Stadium 2018</h5>
                            </div>
                            <div>
                                    <img src="img/achivement2.png" alt="">
                                    <h5 class="rank">1st</h5>
                                    <h5>MPL GG</h5>
                                    <h5>Stadium 2018</h5>
                            </div>
                            <div>
                                    <img src="img/achivement3.png" alt="">
                                    <h5 class="rank">1st</h5>
                                    <h5>Louvae Assembly</h5>
                                    <h5>Stadium 2018</h5>
                            </div>
                    </div>
            </div>
    </div>
    <div class="row">
                    <div class="col-md-6">
                            <h5 class="heading">Raised</h5>
                            <div class="row t m-0">
                                    <div class="col-6 p-0">
                                            <h5>H2H</h5>
                                            <h5>783,450 WGT</h5>
                                            <h5 class="percentage">(30%)</h5>
                                            <a class="btn fund" href="#">Fund</a>
                                    </div>
                                    <div class="col-6 p-0">
                                            <h5>Tornaments</h5>
                                            <h5>1,000,000 WGT</h5>
                                            <h5 class="percentage">(25%)</h5>
                                            <a class="btn fund" href="#">Fund</a>
                                    </div>
                            </div>
                            <div class="row m-0">
                                    <div class="col-12 next-match">
                                            <h5>Next Match  CS :  GO     18 / 08 / 18 <a class="btn btn-sm btn-more" href="#">More</a> </h5>
                            </div>
                            </div>
                    </div>
                    <div class="col-md-6">
                            <h5 class="heading">Vote</h5>
                            <div class="vote">
                                    <ol>
                                            <li>
                                                    <span>Summer Hit 5 Millon Prze Pool</span>
                                                    <p class="like float-right"><i class="fa fa-thumbs-up"></i> 7k</p>
                                            </li> <hr>
                                            <li>
                                                    <span>Tour De france 2 Millon Prze Pool</span>
                                                    <p class="like float-right"><i class="fa fa-thumbs-up"></i> 5.1k</p>
                                            </li> <hr>
                                            <li>
                                                    <span>Euro Cup CS : GO 1 Millon Prze Pool</span>
                                                    <p style="padding-top: 5px" class="like float-right"><i class="fa fa-thumbs-up"></i> 4.1k</p>
                                            </li>
                                    </ol>
                            </div>
                    </div>
            </div>
        </div>
</template>

<script>
export default {
    name: 'MainContent'
}
</script>

<style>

</style>
