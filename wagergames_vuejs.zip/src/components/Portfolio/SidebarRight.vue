<template>
     <div class="col-md-2 p-0">
                                    <div class="sidebar-right">
                                        <div class="card mb-4">
                                                <div class="card-header">
                                                        News
                                                </div>
                                                <div class="card-body">
                                                        <div class="teams">
                                                                        <img src="img/titans.png" alt="titans">
                                                                        <span class="vs">VS</span>
                                                                        <img src="img/blozers.png" alt="blozers"> 
                                                        </div>
                                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                        <p class="text-right date">10-08-2018</p>
                                                </div>
                                        </div>
                                        <div class="card mb-4">
                                                        <div class="card-header">
                                                                2 Game
                                                        </div>
                                                        <div class="card-body">
                                                                <div class="teams">
                                                                                <img class="zoom" src="img/2game.png" alt="2 game">
                                                                </div>
                                                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                               
                                                        </div>
                                                </div>
                                                <div class="card mb-4">
                                                                <div class="card-header">
                                                                        Crane
                                                                </div>
                                                                <div class="card-body">
                                                                        <div class="teams">
                                                                                        <img class="zoom" src="img/crane.png" alt="crane"> 
                                                                        </div>
                                                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                                </div>
                                                        </div>
                                                        <div class="card mb-4">
                                                                <div class="cooming_soon">
                                                                        <p>Cooming <br> Soon</p>
                                                                </div>                           
                                                        </div>
                                    </div>
                            </div>
</template>

<script>
export default {
    name: 'SidebarRight'
}
</script>

<style>

</style>
