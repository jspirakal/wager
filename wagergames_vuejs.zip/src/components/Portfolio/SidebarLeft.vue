<template>
    <div class="col-md-2 p-0">
            <div class="sidebar-left-page3">
                <ul>
                        <li><a href="#"></a>Home<hr></li>
                        <li><a href="#"></a>Team History<hr></li>
                        <li><a href="#"></a>ScreenShot<hr></li>
                        <li><a href="#"></a>Stream<hr></li>
                        <li><a href="#"></a>Stats<hr></li>
                        <li><a href="#"></a>Schedule<hr></li>
                        <li><a href="#"></a>Managers<hr></li>
                        <li><a href="#"></a>Interviews<hr></li>
                        <li><a href="#"></a>Videos<hr></li>
                        <li><a href="#"></a>Gallery<hr></li>
                        <li><a href="#"></a>Online / LAN <hr></li>
                        <li><a href="#"></a>Matches<hr></li>
                        <li><a href="#"></a>Tournaments<hr></li>
                        <li><a href="#"></a>Connect</li>
                </ul>
            </div>
    </div>
</template>

<script>
export default {
    name: 'SidebarLeft'
}
</script>

<style>

</style>
