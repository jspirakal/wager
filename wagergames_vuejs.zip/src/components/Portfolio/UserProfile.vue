<template>
    <div class="row profile">
                <div class="col-md-2 person">
                        <img src="img/person.png" alt="Hero">
                </div>

               <div class="col-md-10">
                   <div class="row">
                        <div class="col-md-6">
                                <h5>Kishor Gujar</h5>
                                <h5>Age: <span class="sky-blue">19</span></h5>
                                <h5>Favourite Role :<span class="sky-blue">Rifel</span></h5>
                                <h5>Alternative ID :<span class="sky-blue">CAT / TOKO</span></h5>
                            </div>
                            <div class="col-md-6">
                                    <h5>World Ranking:<span class="sky-blue"> 177 </span></h5>
                                    <h5>WG Rank:<span class="sky-blue">18</span></h5>
                                    <h5>Game Experience:<span class="sky-blue"> 6 years</span></h5>
                                    <h5>Status:<span class="sky-blue">    Active</span></h5>
                                </div>
                   </div>
                   <div class="row">
                      <div class="col-md-12">
                            <p class="bio"><span>Bio :</span>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                            <div class="float-right">
                                    <a href="#">Read More>></a>
                            </div>
                      </div>
                    </div>
               </div>
            </div>
</template>

<script>
export default {
    name: 'UserProfile'
}
</script>

<style>

</style>
