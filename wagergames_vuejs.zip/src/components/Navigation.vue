<template>
     <nav class="navbar navbar-expand-lg navigation mt-5 bg-dark navbar-dark">
                        <!-- Brand -->
                        <!-- <a class="navbar-brand" href="#">Navbar</a> -->
                      
                        <!-- Toggler/collapsibe Button -->
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                          <span class="navbar-toggler-icon"></span>
                        </button>
                        <!-- Navbar links -->
                        <div class="collapse navbar-collapse" id="collapsibleNavbar">
                          <ul class="navbar-nav">
                            <li class="nav-item">
                              <a class="nav-link" href="#">HOME</a>
                              
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="#">Players</a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="#">Clubs</a>
                            </li> 
                            <li class="nav-item">
                              <a class="nav-link" href="#">Sponsors</a>
                            </li> 
                            <li class="nav-item">
                              <a class="nav-link" href="#">Managers</a>
                            </li> 
                            <li class="nav-item">
                              <a class="nav-link" href="#">Analysers</a>
                            </li> 
                            <li class="nav-item">
                              <a class="nav-link" href="#">Coaches</a>
                            </li> 
                            <li class="nav-item">
                              <a class="nav-link" href="#">Mentors</a>
                            </li> 
                          </ul>
                        </div> 
                      </nav>
</template>
<script>
export default {
  name: 'Navigation',
}
</script>