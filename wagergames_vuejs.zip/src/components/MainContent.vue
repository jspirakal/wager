<template>
    <div class="col-md-8 main-content">
                                 
                                      
                                <h5 class="heading-80"><div class="online"></div>Live Streaming  Tournaments</h5>
                                <div class="tournaments">
                                <div>
                                        <div class="tournament" style="background: url('img/tournament1.png'); background-repeat: no-repeat; height: 270px; background-position: center; ">
                                                <div class="top">
                                                        <h5>LoL</h5>
                                                        <h5>UK Vs Russia</h5>
                                                </div>

                                                <div class="bottom">
                                                        <h5>1 M WGT</h5>
                                                                <h5>Price Pool</h5>
                                                </div>
                                        </div>
                                                        <div class="footer mt-2">
                                                                <a class="btn btn-sm watch" href="#">Watch</a>
                                                                <a class="float-right" href="#"><i class="fa fa-twitch"></i></a>
                                                                <a class="float-right" href="#"><i class="fa fa-youtube"></i></a>
                                                        </div>
                                </div>
                                <div>
                                        <div class="tournament" style="background: url('img/tournament2.png'); background-repeat: no-repeat; height: 270px; background-position: center; ">
                                                <div class="top">
                                                                <h5>FORTNIGHT</h5>
                                                                <h5>UK Vs AUS</h5>
                                                </div>

                                                        <div class="bottom">
                                                                <h5>2 M WGT</h5>
                                                                <h5>Price Pool</h5>
                                                        </div>
                                                
                                                </div>
                                                <div class="footer mt-2">
                                                        <a class="btn btn-sm watch" href="#">Watch</a>
                                                        <a class="float-right" href="#"><i class="fa fa-twitch"></i></a>
                                                        <a class="float-right" href="#"><i class="fa fa-youtube"></i></a>
                                                </div>
                                </div>
                                <div>
                                        <div class="tournament" style="background: url('img/tournament3.png'); background-repeat: no-repeat; height: 270px; background-position: center; ">
                                                <div class="top">
                                                                <h5>LoL</h5>
                                                                <h5>UK Vs Russia</h5>
                                                </div>

                                                        <div class="bottom">
                                                                <h5>1 M WGT</h5>
                                                                <h5>Price Pool</h5>
                                                        </div>
                                                </div>
                                                <div class="footer mt-2">
                                                        <a class="btn btn-sm watch" href="#">Watch</a>
                                                        <a class="float-right" href="#"><i class="fa fa-twitch"></i></a>
                                                        <a class="float-right" href="#"><i class="fa fa-youtube"></i></a>
                                                </div>
                                </div>
                                <div>
                                        <div class="tournament" style="background: url('img/tournament1.png'); background-repeat: no-repeat; height: 270px; background-position: center; ">
                                                <div class="top">
                                                                <h5>LoL</h5>
                                                                <h5>UK Vs Russia</h5>
                                                </div>

                                                        <div class="bottom">
                                                                <h5>1 M WGT</h5>
                                                                <h5>Price Pool</h5>
                                                        </div>
                                                </div>
                                                <div class="footer mt-2">
                                                        <a class="btn btn-sm watch" href="#">Watch</a>
                                                        <a class="float-right" href="#"><i class="fa fa-twitch"></i></a>
                                                        <a class="float-right" href="#"><i class="fa fa-youtube"></i></a>
                                                </div>
                                </div>
                                
                                </div>
                        
                                          
                                               
                               
                                   
                                <h5 class="heading-80"><div class="online"></div>Live Esports Events</h5>
                                <div class="tournaments">
                                                <div>
                                                        <div class="tournament" style="background: url('img/event1.png'); background-repeat: no-repeat; height: 270px; background-position: center; ">
                                                                <div class="top">
                                                                        <h5>LoL</h5>
                                                                        <h5>UK Vs Russia</h5>
                                                                </div>
                
                                                                <div class="bottom">
                                                                        <h5>1 M WGT</h5>
                                                                                <h5>Price Pool</h5>
                                                                </div>
                                                        </div>
                                                                        <div class="footer mt-2">
                                                                                <a class="btn btn-sm watch" href="#">Watch</a>
                                                                                <a class="float-right" href="#"><i class="fa fa-twitch"></i></a>
                                                                                <a class="float-right" href="#"><i class="fa fa-youtube"></i></a>
                                                                        </div>
                                                </div>
                                                <div>
                                                        <div class="tournament" style="background: url('img/event2.png'); background-repeat: no-repeat; height: 270px; background-position: center; ">
                                                                <div class="top">
                                                                                <h5>FORTNIGHT</h5>
                                                                                <h5>UK Vs AUS</h5>
                                                                </div>
                
                                                                        <div class="bottom">
                                                                                <h5>2 M WGT</h5>
                                                                                <h5>Price Pool</h5>
                                                                        </div>
                                                                
                                                                </div>
                                                                <div class="footer mt-2">
                                                                        <a class="btn btn-sm watch" href="#">Watch</a>
                                                                        <a class="float-right" href="#"><i class="fa fa-twitch"></i></a>
                                                                        <a class="float-right" href="#"><i class="fa fa-youtube"></i></a>
                                                                </div>
                                                </div>
                                                <div>
                                                        <div class="tournament" style="background: url('img/event3.png'); background-repeat: no-repeat; height: 270px; background-position: center; ">
                                                                <div class="top">
                                                                                <h5>LoL</h5>
                                                                                <h5>UK Vs Russia</h5>
                                                                </div>
                
                                                                        <div class="bottom">
                                                                                <h5>1 M WGT</h5>
                                                                                <h5>Price Pool</h5>
                                                                        </div>
                                                                </div>
                                                                <div class="footer mt-2">
                                                                        <a class="btn btn-sm watch" href="#">Watch</a>
                                                                        <a class="float-right" href="#"><i class="fa fa-twitch"></i></a>
                                                                        <a class="float-right" href="#"><i class="fa fa-youtube"></i></a>
                                                                </div>
                                                </div>
                                                <div>
                                                        <div class="tournament" style="background: url('img/tournament1.png'); background-repeat: no-repeat; height: 270px; background-position: center; ">
                                                                <div class="top">
                                                                                <h5>LoL</h5>
                                                                                <h5>UK Vs Russia</h5>
                                                                </div>
                
                                                                        <div class="bottom">
                                                                                <h5>1 M WGT</h5>
                                                                                <h5>Price Pool</h5>
                                                                        </div>
                                                                </div>
                                                                <div class="footer mt-2">
                                                                        <a class="btn btn-sm watch" href="#">Watch</a>
                                                                        <a class="float-right" href="#"><i class="fa fa-twitch"></i></a>
                                                                        <a class="float-right" href="#"><i class="fa fa-youtube"></i></a>
                                                                </div>
                                                </div>
                                                
                                                </div>
                                                <h5 class="heading-80">Upcomming Events</h5>
                                                
                                                <ul class="nav-md">
                                                        <li><a href="#">USA</a></li>
                                                        <li><a href="#">UK</a></li>
                                                        <li><a href="#">AUSTRALIA</a></li>
                                                        <li><a href="#">SINGAPORE</a></li>
                                                        <li><a href="#">JAPAN</a></li>
                                                        <li><a href="#">RUSSIA</a></li>
                                                </ul>
                                                
                                                
                                                <h5 class="heading-80 mb-5 mt-5">WagerGames Portfolio</h5>

                                                <div class="row mt-4 portfolio">
                                                        <div class="col-md-3" style="background: url('img/portfolio1.png'); background-repeat: no-repeat; background-position: center">
                                                                <div class="content">
                                                                                <h5>Snooker</h5>
                                                                                <h5>5423</h5>
                                                                                <h5><div class="online"></div>Players Online</h5>
                                                                        </div>
                                                                </div>
                                                                <div class="col-md-3" style="background: url('img/portfolio2.png'); background-repeat: no-repeat; background-position: center">
                                                                        <div class="content">
                                                                                <h5>Golf</h5>
                                                                                <h5>4752</h5>
                                                                                <h5><div class="online"></div>Players Online</h5>
                                                                </div>

                                                        </div>
                                                        <div class="col-md-3" style="background: url('img/portfolio3.png'); background-repeat: no-repeat; background-position: center">
                                                                        <div class="content">
                                                                                        <h5>Bowling</h5>
                                                                                        <h5>3742</h5>
                                                                                        <h5><div class="online"></div>Players Online</h5>
                                                                        </div>

                                                               
                                                        </div>
                                                        <div class="col-md-3" style="background: url('img/portfolio4.png'); background-repeat: no-repeat; background-position: center">
                                                                <div class="content">
                                                                                <h5>Basketball</h5>
                                                                                <h5>242</h5>
                                                                                <h5><div class="online"></div>Players Online</h5>
                                                                </div>

                                                       
                                                </div>
                                                </div>

                                                <h5 class="heading-80 mb-5 mt-5">Latest News </h5>
                                                <div class="row main-news">
                                                        <div class="col-md-3">
                                                                <img src="img/news1.png" alt="">
                                                                <p class="news">Bitcoin Funded Silk Road Performance Earns a Residency at Trafalgar Studios</p>
                                                        </div>

                                                        <div class="col-md-3">
                                                                <img src="img/news2.png" alt="">
                                                                <p class="news">This Week in Bitcoin: McAfee Backs Off, Crypto World Cup and the Mystery </p>
                                                        </div>
                                                        <div class="col-md-3">
                                                                <img src="img/news3.png" alt="">
                                                                <p class="news">The Bitcoin-Culture Invasion: T-Shirts, Hats, Candles, Mugs, and More</p>
                                                        </div>
                                                        <div class="col-md-3">
                                                                <img src="img/news4.png" alt="">
                                                                <p class="news">US Secret Service Asks Congress For Help 
                                                                                to Prevent illicit Use Of Privacy Coins</p>
                                                        </div>
                                                </div>
                            </div>
                           
</template>

<script>
export default {
    name: 'MainContent'
}
</script>
