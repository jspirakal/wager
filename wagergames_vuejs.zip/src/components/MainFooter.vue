<template>
     <div class="container">
        <div class="col-md-12 mb-5">
               <div class="social">
                        <ul>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                <hr width="40%">
                        </ul>
               </div>
        </div>

     <footer class="mt-5">
                <div class="col-md-12">
                                <div class="row">
                                        <div class="col-md-4">
                                                <h5>Contact</h5>
                                                <ul>
                                                        <li>Live Chat</li>
                                                        <li>Email: Support@wagergames.io</li>
                                                </ul>
                                        </div>
                                        <div class="col-md-4">
                                                <h5>About</h5>
                                                <ul>
                                                        <li>Company</li>
                                                        <li>Developers</li>
                                                </ul>
                                        </div>
                                        <div class="col-md-4">
                                                <h5>Help</h5>
                                                <ul>
                                                        <li>Terms & Conditions </li>
                                                        <li>Privacy Policy</li>
                                                </ul>
                                        </div>
                                </div>
                        </div>

                        <div class="col-md-12 mt-5 mb-5">
                                <p class="copyright">Copyright © Wager Games. All rights reserved</p>
                        </div>
     </footer>

    </div>
</template>

<script>
export default {
    name: 'MainFooter'
}
</script>

<style>

</style>
